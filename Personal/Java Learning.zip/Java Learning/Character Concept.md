Primitive data type to store 16-bit (2 bytes) Unicode characters. Hence, this data type  can store more than ASCII.
#### Converting to String
```java
char myChar = 'A';
String myString = String.valueOf(myChar);
```