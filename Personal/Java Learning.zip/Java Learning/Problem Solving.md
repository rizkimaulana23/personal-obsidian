### Reverse String

### Reverse Array
I want to reverse this array so that it has the algorithm of O(n/2). Well, it is still counts as a O(n).

1. Mengecek panjang dari Array. Jika panjangnya adalah bilangan Ganjil, maka kita akan melakukan iterasi sebanyak n/2-1 kali. Sedangkan jika panjangnya adalah bilangan genap, kita akan melakukan iterasi sebanyak n/2.
#### String Anagram
If we could use, 